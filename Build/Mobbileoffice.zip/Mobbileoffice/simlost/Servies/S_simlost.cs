﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using simlost.Models;
using simlost.Repositories;


namespace simlost.Servies
{
  public  class S_simlost
    {
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="userName">手机号</param>
        /// <param name="userPwd">密码</param>
        /// <returns></returns>
        public bool Login(string userName, string userPwd)
        {


            R_simlost kb = new R_simlost();
            simlostInfo user = kb.GetUserDetil(userName);
            if (user == null || userPwd != user.uPass)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <returns></returns>
        public int AddViewCount(string ACCOUNT)

        {
            R_simlost kb = new R_simlost();

            return kb.AddViewCount2(ACCOUNT);
        }
    }
}
