﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PetaPoco;
using simlost.Models;

namespace simlost.Repositories
{
   public class R_simlost
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 通过手机号调取相应内容
        /// </summary>
        /// <param name="mobileNum">手机号</param>
        /// <returns></returns>
        public simlostInfo GetUserDetil(string mobileNum)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", mobileNum);

            return DB.FirstOrDefault<simlostInfo>(sql);
        }
        /// <summary>
        /// 通过手机号修改状态
        /// </summary>
        /// <param name="mobileNum">手机号</param>
        /// <returns></returns>
        public int AddViewCount2(string mobileNum)

        {

            Sql sql2 = Sql.Builder.Append("Update tbl_user set STATUS=2 where mobileNum =@0", mobileNum);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
    }
}
