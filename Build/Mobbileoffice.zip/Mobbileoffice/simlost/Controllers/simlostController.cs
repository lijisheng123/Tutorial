﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using login;
using BankSystem.Controllers.Filters;
using simlost.Models;
using simlost.Servies;

namespace Mobbileoffice.Controllers
{
    public class simlostController : Controller
    {
        // GET: simlost
       S_simlost   Access = new S_simlost();
        /// <summary>
        /// 挂失SIM卡
        /// </summary>
        /// <returns>返回数据</returns>
        [Login]
        
        #region 挂失SIM卡
        public ActionResult simlostView()
        {

            return View();
        }
        [Login]
        [HttpPost]

        public ActionResult simlostView( simlostInfo sk)
        {
            if (!ModelState.IsValid)
            {
                return View(sk);
            }

           
            sk.uPass = ReUse.BllUtility.MD5AndSHA1.MD5Encode(sk.uPass, "32");



            if (Access.Login(sk.mobileNum, sk.uPass))
            {
                Access.AddViewCount(sk.mobileNum);
                ViewBag.ts1 = "挂失成功";
                return View(sk);


            }
            else
            {
                ViewBag.ts1 = "挂失失败";
                return View(sk);

            }



        }
        #endregion
    }
}