﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace simlost.Models
{
  public  class simlostInfo
    {
        /// <summary>
        /// 手机号
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "手机号必输输入")]
        [RegularExpression(@"\d{11}", ErrorMessage = "手机号格式不对")]
        public string mobileNum { get; set; }
        /// <summary>
        /// 登录密码
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "密码必输输入")]
        [RegularExpression(@"\d{6}", ErrorMessage = "密码必须由0-9组成的六位数字")]
        public string uPass { get; set; }
    }
}
