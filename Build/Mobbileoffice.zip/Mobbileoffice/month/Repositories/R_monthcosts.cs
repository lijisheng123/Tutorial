﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using month.Models;
using PetaPoco;

namespace month.Repositories
{
   public class R_monthcosts
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 查询数据综合
        /// </summary>
        /// <param name="mobileNum">手机号</param>
        /// <param name="month">月份</param>
        /// <returns>返回数据</returns>
        public string ExecutsScalar(string mobileNum,DateTime month)
        {
            string where = string.Format("mobileNum={0} and datediff(MONTH,actionTime,'{1}')=0 ", mobileNum, month);
            Sql sql = Sql.Builder
                .Select("SUM(mnNum)")
                .From(" tbl_actlog")
                .Where(where);

            return DB.ExecuteScalar<string>(sql);
        }

    }
}
