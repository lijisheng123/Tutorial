﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using month.Models;
using PetaPoco;

namespace month.Repositories
{
  public  class R_detailed
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="Page">页数</param>
        /// <param name="ItemsPerPage"></param>
        /// <param name="mobileNum">手机号</param>
        /// <param name="month">月份</param>
        /// <returns>返回数据列表</returns>

        public Page<detailedInfo> user(long Page, long ItemsPerPage, string mobileNum, DateTime month)
        {
            string where = string.Format("mobileNum={0} and datediff(MONTH,actionTime,'{1}')=0 ", mobileNum, month);
            Sql sql = Sql.Builder
                .Select("*")
                .From(" tbl_actlog")
                .Where(where);

            return DB.Page<detailedInfo>(Page, ItemsPerPage, sql);
        }
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="Page">页数</param>
        /// <param name="ItemsPerPage"></param>
        /// <param name="account">手机号</param>
        /// <returns>返回数据列表</returns>
        public Page<detailedInfo> user(long Page, long ItemsPerPage, string account)
        {
            string where = string.Format("mobileNum = {0} ", account);
            Sql sql = Sql.Builder
                .Select("*")
                .From(" tbl_actlog")
                .Where(where);

            return DB.Page<detailedInfo>(Page, ItemsPerPage, sql);
        }
    }
}
