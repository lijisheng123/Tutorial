﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace month.Models
{
   public class monthcostsInfo
    {
        /// <summary>
        /// 手机号
        /// </summary>
      
        public string mobileNum { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public DateTime actionTime { get; set; }
    }
}
