﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace month.Models
{
  public  class detailedInfo
    {
        /// <summary>
        /// 手机号
        /// </summary>

        public string mobileNum { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public DateTime actionTime { get; set; }
        /// <summary>
        /// 种类
        /// </summary>
        public string actionName { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string actionBrief { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        public decimal mnNum { get; set; }
    }
}
