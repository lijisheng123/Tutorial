﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PetaPoco;
using BankSystem.Controllers.Filters;
using login;
using month.Servies;
using month.Models;

namespace Mobbileoffice.Controllers
{
    public class monthcostsController : Controller
    {
        login.Models.Logininfo currUseer = UserState.GetUserStatic();
        S_detailed BA = new S_detailed();
        // GET: monthcosts
        /// <summary>
        /// 月详单查询
        /// </summary>
        /// <param name="Access">model类</param>
        /// <returns>返回数据</returns>
        #region 月详单查询
        [Login]
        public ActionResult detailedView(detailedInfo Access)
        {
            Access.mobileNum = currUseer.mobileNum;


            ViewBag.ss = currUseer.mobileNum;
            int CurrPage;
            int.TryParse(Request.QueryString["page"], out CurrPage);
            CurrPage = CurrPage <= 0 ? 1 : CurrPage;
            Page<detailedInfo> PageUInfo = BA.xx(CurrPage, Access.mobileNum);
            return View(PageUInfo);

        }

        [Login]
        [HttpPost]
        public ActionResult detailedView(FormCollection fc, detailedInfo Access)
        {
            if (fc["yue"]==null)
            {
                Access.mobileNum = currUseer.mobileNum;


                ViewBag.ss = currUseer.mobileNum;
                int CurrPage2;
                int.TryParse(Request.QueryString["page"], out CurrPage2);
                CurrPage2 = CurrPage2 <= 0 ? 1 : CurrPage2;
                Page<detailedInfo> PageUInfo2 = BA.xx(CurrPage2, Access.mobileNum);
                return View(PageUInfo2);
            }
            Access.mobileNum = currUseer.mobileNum;
            string year = Convert.ToString(DateTime.Now.Year.ToString());
            
            DateTime month = Convert.ToDateTime(string.Format("{0}-{1}-{2}", year, fc["yue"], 01));

            int CurrPage;
            int.TryParse(Request.QueryString["page"], out CurrPage);
            CurrPage = CurrPage <= 0 ? 1 : CurrPage;
            Page<detailedInfo> PageUInfo = BA.xx(CurrPage, Access.mobileNum, month);
            return View(PageUInfo);
        }
        #endregion
        /// <summary>
        /// 月账单查询
        /// </summary>
        /// <returns>返回数据</returns>
        #region 月账单查询
        [Login]
        public ActionResult monthcostsView()
        {
            ViewBag.zh = "【账单查询】"+currUseer.mobileNum;
            return View();

        }
        [Login]
        [HttpPost]
        public ActionResult monthcostsView(FormCollection fc)
        {
            if (fc["yue"] == null)
            {
                ViewBag.zh = "【账单查询】" + currUseer.mobileNum;
                ViewBag.ze = "请选择月份";
                return View();
            }
            else
            {
                S_monthcosts sk = new S_monthcosts();
                string year = Convert.ToString(DateTime.Now.Year.ToString());
                DateTime month = Convert.ToDateTime(string.Format("{0}-{1}-{2}", year, fc["yue"], 01));
                if (sk.ExecutsScalar(currUseer.mobileNum, month) ==null)
                {
                    ViewBag.zh = "【账单查询】" + currUseer.mobileNum;
                    ViewBag.ze = DateTime.Now.Year.ToString() + "年" + fc["yue"] + "月," + "未查到消费记录";
                    return View();
                }
                else
                {
                    ViewBag.ze = DateTime.Now.Year.ToString() + "年" + fc["yue"] + "月," + "话费总额为" + sk.ExecutsScalar(currUseer.mobileNum, month);
                    ViewBag.zh = "【账单查询】" + currUseer.mobileNum;
                    return View();
                }
            }
        }
        #endregion 月账单查询
    }
}