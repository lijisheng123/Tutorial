﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using month.Repositories;

namespace month.Servies
{
   public class S_monthcosts
    {
        /// <summary>
        ///  调用Repositories
        /// </summary>
        /// <param name="mobileNum">手机号</param>
        /// <param name="month">月份</param>
        /// <returns>返回数据</returns>
        public string ExecutsScalar(string mobileNum, DateTime month)
        {
            R_monthcosts DB = new R_monthcosts();

            return DB.ExecutsScalar(mobileNum, month);
        }
    }
}
