﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PetaPoco;
using month.Models;
using month.Repositories;

namespace month.Servies
{
   public class S_detailed
    {
        /// <summary>
        /// 调用Repositories
        /// </summary>
        /// <param name="CurrPage">月数</param>
        /// <param name="mobileNum">手机号</param>
        /// <param name="month">月份</param>
        /// <returns>返回数据</returns>
        public Page<detailedInfo> xx(long CurrPage, string mobileNum, DateTime month)
        {
            R_detailed BA = new R_detailed();

            return BA.user(CurrPage, 3, mobileNum, month);
        }
        /// <summary>
        ///  调用Repositories
        /// </summary>
        /// <param name="CurrPage">月数</param>
        /// <param name="mobileNum">手机号</param>
        /// <returns>返回数据</returns>
        public Page<detailedInfo> xx(long CurrPage, string mobileNum)
        {
            R_detailed BA = new R_detailed();

            return BA.user(CurrPage, 3, mobileNum);
        }
    }
}
