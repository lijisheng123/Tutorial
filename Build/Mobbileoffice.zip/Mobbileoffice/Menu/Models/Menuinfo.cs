﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menu.Models
{
  public  class MenuInfo
    {
        /// <summary>
        /// 手机号
        /// </summary>
       
        public string mobileNum { get; set; }
      
        /// <summary>
        /// 姓名
        /// </summary>
    
        public string uName { get; set; }

        /// <summary>
        /// 性别
        /// </summary>

        public int uSex { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
   
        public string uAddress { get; set; }
        /// <summary>
        /// 邮编
        /// </summary>   
      
        public string uPostcode { get; set; }
    
        /// <summary>
        /// 余额
        /// </summary>
        public decimal balance { get; set; }
    }
}
