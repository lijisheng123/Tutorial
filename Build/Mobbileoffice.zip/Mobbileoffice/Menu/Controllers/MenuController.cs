﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Menu.Models;
using Menu.Servies;
using BankSystem.Controllers.Filters;
using login;

namespace Mobbileoffice.Controllers
{

    public class MenuController : Controller
    {

        // GET: Menu
        login.Models.Logininfo currUseer = UserState.GetUserStatic();
        MenuInfo info = new MenuInfo();
        // GET: Menu
        /// <summary>
        /// 菜单
        /// </summary>
        /// <returns>返回数据</returns>
        #region 菜单
        [Login]
        public ActionResult MenuView()
        {
            info.mobileNum = currUseer.mobileNum;

            ViewBag.ACCOUNT = currUseer.mobileNum;
            S_Menu sk = new S_Menu();
            info = sk.Login(info.mobileNum);
            Session["Name"] = info.uName;
            if (info.uSex == 0)
            {
                ViewBag.sex = "男";
            }
            else
            {
                ViewBag.sex = "女";
            }
            return View(info);
        }
        #endregion
    }
}