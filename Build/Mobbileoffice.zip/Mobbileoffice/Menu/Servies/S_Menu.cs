﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Menu.Repositories;
using Menu.Models;

namespace Menu.Servies
{
   public class S_Menu
    {
        /// <summary>
        /// 调用Repositories
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回数据</returns>
        public MenuInfo Login(string user)
        {


            R_Menu kb = new R_Menu();
            return kb.GetUserDetil(user);

        }
    }
}
