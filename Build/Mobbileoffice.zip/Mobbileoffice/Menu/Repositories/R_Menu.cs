﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Menu.Models;
using PetaPoco;

namespace Menu.Repositories
{
   public class R_Menu
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回数据</returns>
        public MenuInfo GetUserDetil(string user)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", user);

            return DB.FirstOrDefault<MenuInfo>(sql);
        }
    }
}
