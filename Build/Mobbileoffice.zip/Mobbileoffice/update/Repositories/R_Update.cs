﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PetaPoco;
using update.Models;

namespace update.Repositories
{
  public  class R_Update
    {
        /// <summary>
        /// 通过手机号获取内容
        /// </summary>
        private Database DB = new Database("ConnString");
        public UpdateInfo GetUserDetil(string user)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", user);
            return DB.FirstOrDefault<UpdateInfo>(sql);
        }
        /// <summary>
        /// 通过手机号修改
        /// </summary>
        /// <param name="uinfo">model类</param>
        /// <returns>返回数据</returns>
        public object UserUpdate(UpdateInfo uinfo)
        {

            return DB.Update("tbl_user", "mobileNum", uinfo);
        }
        /// <summary>
        /// 通过手机号修改密码
        /// </summary>
        /// <param name="uinfo">model类</param>
        /// <returns>返回数据</returns>
        public object PassUpdate(Upass uinfo)
        {

            return DB.Update("tbl_user", "mobileNum", uinfo);
        }
    }
}
