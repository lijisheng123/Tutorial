﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace update.Models
{
  public  class UpdateInfo
    {
        /// <summary>
        /// 手机号
        /// </summary>
      
        public string mobileNum { get; set; }
      
        /// <summary>
        /// 姓名
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "姓名必输输入")]
        public string uName { get; set; }

        /// <summary>
        /// 性别
        /// </summary>

        public int uSex { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "地址必输输入")]
        public string uAddress { get; set; }
        /// <summary>
        /// 邮编
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = "邮编必输输入")]
        [RegularExpression(@"\d{6}", ErrorMessage = "邮编必须为六位数字")]
        public string uPostcode { get; set; }
        /// <summary>
        /// 电子邮件
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = "电子邮件必输输入")]
        public string email { get; set; }
        /// <summary>
        ///安全提示问题
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = "安全提示问题必输输入")]
        public string question { get; set; }
        /// <summary>
        /// 安全答案
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = " 安全答案必输输入")]
        public string answer { get; set; }
      
      
     
       
    }
}
