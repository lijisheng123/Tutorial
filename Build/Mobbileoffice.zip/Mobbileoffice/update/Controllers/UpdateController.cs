﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using update.Models;
using update.Servies;
using login;
using BankSystem.Controllers.Filters;
namespace Mobbileoffice.Controllers
{
    public class UpdateController : Controller
    {
        S_Update su = new S_Update();
        login.Models.Logininfo currUser = UserState.GetUserStatic();
      
        // GET: Update
        /// <summary>
        /// 修改资料
        /// </summary>
        /// <returns>返回数据</returns>
        [Login]
        #region 修改资料
        public ActionResult UpdateView()
        {


            UpdateInfo uinfo = su.GetUserDetil(currUser.mobileNum);
            ViewBag.Account = currUser.mobileNum;
            return View(uinfo);
        }
        [HttpPost]
        [Login]
        public ActionResult UpdateView( UpdateInfo info )
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Account = currUser.mobileNum;
                return View(info);
            }
            UpdateInfo uinfo = su.GetUserDetil(currUser.mobileNum);
            info.mobileNum = currUser.mobileNum;
            su.UserUpdate(info);
            ViewBag.ts = "修改成功";
            ViewBag.Account = currUser.mobileNum;
            return View(info);
        }
        #endregion
        /// <summary>
        /// 密码修改
        /// </summary>
        /// <returns>返回数据</returns>
        #region 密码修改
        [Login]
        public ActionResult UpassView()
        {
            ViewBag.Account = currUser.mobileNum;
            return View();
        }
        [HttpPost]
        [Login]
        public ActionResult UpassView(Upass info,FormCollection sk)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Account = currUser.mobileNum;
                return View(info);
            }
            ViewBag.Account = currUser.mobileNum;
            info.mobileNum = currUser.mobileNum;
            string pass = sk["Password"];
            if (pass == info.uPass)
            {
                info.uPass= ReUse.BllUtility.MD5AndSHA1.MD5Encode(info.uPass, "32");
                su.PassUpdate(info);
                ViewBag.ps1 = "修改成功";
                return View(info);
            }
            else
            {
                @ViewBag.sss = "两次密码不一样";
                return View(info);
            }
          
        }
        #endregion
    }
}