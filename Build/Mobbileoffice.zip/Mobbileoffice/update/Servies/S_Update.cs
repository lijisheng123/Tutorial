﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using update.Repositories;
using update.Models;

namespace update.Servies
{
  public  class S_Update
    {
        R_Update sk = new R_Update();
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回数据</returns>
        public UpdateInfo GetUserDetil(string user)
        {
            return sk.GetUserDetil(user);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="uinfo">手机号</param>
        /// <returns>返回数据</returns>
        public object UserUpdate(UpdateInfo uinfo)
        {

            return sk.UserUpdate(uinfo);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="uinfo">手机号</param>
        /// <returns>返回数据</returns>
        public object PassUpdate(Upass uinfo)
        {

            return sk.PassUpdate(uinfo);
        }
    }
}
