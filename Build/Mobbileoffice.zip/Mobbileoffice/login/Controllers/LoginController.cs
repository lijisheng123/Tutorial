﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using login.Servies;
using login.Models;
using login;

namespace Mobbileoffice.Controllers
{
    public class LoginController : Controller
    {
        
        /// <summary>
        /// 用户登录
        /// </summary>
        #region 用户登录
        S_Login Access = new S_Login();
        Logininfo uInfo = new Logininfo();
      
        public ActionResult LoginView()
        {

            return View(uInfo);
        }
        public ActionResult CheckCode()
        {
            return File(Core.CheckCode.Code.CheckCode.RndCodeImg(), "image/gif");
        }
        [HttpPost]

        public ActionResult LoginView(Logininfo sk, FormCollection fc)
        {
            string UserInput = fc["CheckCode"] ?? string.Empty;
            string SavedCode = (string)Session["rndcode"];
            if (!UserInput.ToLower().Equals(SavedCode))
            {
                var isadmintips = ("<script>alert('验证码输入错误！');document.location.href='/Login/LoginView';</script>");
                return Content(isadmintips);
               
            }

            if (!ModelState.IsValid)
            {
                return View(sk);
            }
            sk.uPass = ReUse.BllUtility.MD5AndSHA1.MD5Encode(sk.uPass, "32");
            if (Access.Login(sk.mobileNum, sk.uPass))
            {

                UserState.SaveUserState(sk);
                return RedirectToAction("MenuView", "Menu");
            }
            else
            {
                var isadmintips = ("<script>alert('登录失败，如有疑问请联系管理员');document.location.href='/Login/LoginView';</script>");
                return Content(isadmintips);
              
            }
        }
        #endregion
        /// <summary>
        /// 管理员登录
        /// </summary>
        /// <returns>返回数据</returns>
        #region 管理员登录
       
        public ActionResult AdminView()
        {
            return View(uInfo);
        }
        [HttpPost]
        public ActionResult AdminView(Logininfo sk, FormCollection sd)
        {



            if (!ModelState.IsValid)
            {
                return View(sk);
            }
            else
            {

                if (sd["mobileNum"] == "17806247255" && sd["uPass"] == "123456")
                {
                    Session["Login"] = sk.mobileNum;
                    return RedirectToAction("deleatView", "deleat");
                }
                else
                {
                    var isadmintips = ("<script>alert('管理员如忘记密码，请联系制作人员！！！！！');document.location.href='/Login/LoginView';</script>");
                    return Content(isadmintips);
                  
                }
            }


        }
        #endregion
    }
}