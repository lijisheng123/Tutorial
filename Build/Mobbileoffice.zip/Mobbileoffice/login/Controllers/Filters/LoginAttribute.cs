﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using login.Models;
using login.Servies;


namespace BankSystem.Controllers.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]

    public class LoginAttribute : FilterAttribute, IAuthorizationFilter
    {
        // GET: LoginAttribute
            public void OnAuthorization(AuthorizationContext filterContext)
            {
                if (filterContext.IsChildAction)
                {
                    return;
                }
                Logininfo CurrUser = login.UserState.GetUserStatic();
                if (CurrUser == null)
                {
                    filterContext.Result = new RedirectResult("/Login/LoginView");
                }
            }
        }
    }
