﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using login.Models;
using PetaPoco;
namespace login.Repositories
{
  public   class R_Login
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="phone">手机号</param>
        /// <returns>返回数据</returns>
        public Logininfo GetUserDetil(string phone)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", phone);

            return DB.FirstOrDefault<Logininfo>(sql);
        }
    }
}
