﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using login.Models;
using login.Repositories;

namespace login.Servies
{
  public  class S_Login
    {
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="mobileNum">手机号</param>
        /// <param name="uPass">密码</param>
        /// <returns>返回数据</returns>
        public bool Login(string mobileNum, string uPass)
        {


            R_Login kb = new R_Login();
            Logininfo user = kb.GetUserDetil(mobileNum);


            if (user == null || uPass != user.uPass)
            {
                return false;
            }
            else
            {
                if (user.status == 0 || user.status == 2)
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }


        }
    }
}
