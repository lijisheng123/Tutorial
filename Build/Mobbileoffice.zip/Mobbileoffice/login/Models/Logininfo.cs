﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace login.Models
{
  public  class Logininfo
    {
        /// <summary>
        /// 手机号
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "手机号必输输入")]
        [RegularExpression(@"\d{11}", ErrorMessage = "手机号格式不对")]
        public string mobileNum { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "密码必须输入！")]
        public string uPass { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int status { get; set; }
    }
}
