﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using login.Models;
using System.Web;

namespace login
{
    public class UserState
    {
       
        public static void SaveUserState(Logininfo CurrUser)
        {
            HttpContext.Current.Session["LoginCode"] = CurrUser;
        }
        public static Logininfo GetUserStatic()
        {
            Logininfo CurrUser = (Logininfo)HttpContext.Current.Session["LoginCode"];
            return CurrUser;
        }
    }
}
