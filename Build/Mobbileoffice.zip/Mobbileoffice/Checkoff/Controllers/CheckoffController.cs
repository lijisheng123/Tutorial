﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Checkoff.Models;
using Checkoff.Servies;
using login;
using BankSystem.Controllers.Filters;
namespace Mobbileoffice.Controllers
{
    public class CheckoffController : Controller
    {
        login.Models.Logininfo currUser = UserState.GetUserStatic();
        // GET: Checkoff
        /// <summary>
        /// 第三方代扣
        /// </summary>
        /// <returns>返回视图</returns>
        #region 第三方代扣

        [Login]
        public ActionResult CheckoffView()
        {
            ViewBag.Account = currUser.mobileNum;
            item();
            return View();
        }
        [HttpPost]
       
        [Login]
      
        public ActionResult CheckoffView(Loginfo info)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Account = currUser.mobileNum;
                item();
                return View(info);
            }
            S_Checkoff sk = new S_Checkoff();
           Checkoffinfo sb = sk.GetUserDetil2(currUser.mobileNum);
            if (sb.balance > info.mnNum)
            {
                info.mnType = 0;
                info.actionTime = DateTime.Now;
                info.actionName = "第三方代扣";
                info.mobileNum = currUser.mobileNum;
                sk.UserReg(info);
                sk.AddViewCount(info.mobileNum, info.mnNum);
                ViewBag.ps1 = "充值成功";
                item();
                ViewBag.Account = currUser.mobileNum;
                return View();
            }
            else
            {
                item();
                ViewBag.ps1 = "余额不足";
                ViewBag.Account = currUser.mobileNum;
                return View();

            }

           
        }
        public void item()
        {
            IList<SelectListItem> ListItems = new List<SelectListItem>();
            string[] System = { "腾讯QQ包月费", "腾讯QQ黄钻", "腾讯QQ会员", "腾讯QQ红钻", "腾讯Q币充值" };
            for (int i = 0; i < System.Length; i++)
            {
                SelectListItem TheItem = new SelectListItem();
                TheItem.Value = TheItem.Text = string.Format("{0}", System[i]);
                ListItems.Add(TheItem);
            }
            ViewBag.ListItems = ListItems;
        }
        #endregion

    }
}