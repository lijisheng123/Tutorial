﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Checkoff.Models;
using PetaPoco;

namespace Checkoff.Repositories
{
    public class R_Checkoff
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 向tbl_actlog插入数据
        /// </summary>
        /// <param name="uInfo">model类</param>
        /// <returns>向tbl_actlog插入数据</returns>
        public object UserReg(Loginfo uInfo)
        {
            return DB.Insert("tbl_actlog", "logId ", uInfo);
        }
        /// <summary>
        /// 扣费
        /// </summary>
        /// <param name="ACCOUNT">账号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>修改信息</returns>
        public int AddViewCount(string ACCOUNT, decimal BALANCE)

        {
            string sql = string.Format("Update tbl_user set balance = balance - {0} where mobileNum ={1}", BALANCE, ACCOUNT);
            Sql sql2 = Sql.Builder.Append(sql);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
        /// <summary>
        /// 通过手机号查询信息
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回查询数据</returns>
        public Checkoffinfo GetUserDetil2(string user)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", user);

            return DB.FirstOrDefault<Checkoffinfo>(sql);
        }
    }
}
