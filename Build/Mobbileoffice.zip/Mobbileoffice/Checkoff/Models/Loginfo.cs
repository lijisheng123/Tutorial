﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Checkoff.Models
{
  public  class Loginfo
    {
        /// <summary>
        /// 账号
        /// </summary>

        public string mobileNum { get; set; }
        /// <summary>
        /// 消费类型
        /// </summary>
        public int mnType { get; set; }

        /// <summary>
        /// 金额
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "金额必输输入")]
        [RegularExpression(@"[0-9]+", ErrorMessage = "格式错误")]
        public Decimal mnNum { get; set; }
        /// <summary>
        /// 操作标志
        /// </summary>
        public string actionName { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public DateTime actionTime { get; set; }
        /// <summary>
        /// 第三方代扣
        /// </summary>
        public string actionBrief { get; set; }
    }
}
