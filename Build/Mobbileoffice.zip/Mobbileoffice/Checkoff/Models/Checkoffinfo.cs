﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkoff.Models
{
  public  class Checkoffinfo
    {
        /// <summary>
        /// 电话号码
        /// </summary>
        public string mobileNum { get; set; }
        /// <summary>
        /// 余额
        /// </summary>
        public decimal balance { get; set; }
      
    }
}
