﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Checkoff.Models;
using Checkoff.Repositories;

namespace Checkoff.Servies
{
   public class S_Checkoff
    {
        R_Checkoff DB = new R_Checkoff();
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="uInfo">手机号</param>
        /// <returns>将数据传入Repositories层</returns>
        public object UserReg(Loginfo uInfo)
        {
            return DB.UserReg(uInfo);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>将手机号余额传入Repositories层</returns>
        public int AddViewCount(string ACCOUNT, decimal BALANCE)

        {

            return DB.AddViewCount(ACCOUNT, BALANCE);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回查询数据</returns>
        public Checkoffinfo GetUserDetil2(string user)
        {


            return DB.GetUserDetil2(user);
        }
    }
}
