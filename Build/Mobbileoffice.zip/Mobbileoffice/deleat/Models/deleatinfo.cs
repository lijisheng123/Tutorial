﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace deleat.Models
{
  public  class deleatinfo
    {
        /// <summary>
        /// 电话号码
        /// </summary>
        public string mobileNum { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string uName { get; set; }
        /// <summary>
        /// 性别
        /// </summary>

        public int uSex { get; set; }
        /// <summary>
        /// 最后登录时间
        /// </summary>
        public DateTime lasttime { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int STATUS { get; set; }
        /// <summary>
        /// 余额
        /// </summary>
        public decimal balance { get; set; }
        /// <summary>
        /// 登录密码
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "密码必输输入")]
        [RegularExpression(@"\d{6}", ErrorMessage = "密码必须由0-9组成的六位数字")]
        public string uPass { get; set; }
    }
}
