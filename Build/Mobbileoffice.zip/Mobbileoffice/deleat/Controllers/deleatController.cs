﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PetaPoco;
using deleat.Models;
using deleat.Servies;

namespace Mobbileoffice.Controllers
{
    public class deleatController : Controller
    {
        S_deleat Access = new S_deleat();
        /// <summary>
        /// 后台管理
        /// </summary>
        /// <returns>返回数据</returns>
        // GET: deleat
        #region 后台管理
        public ActionResult deleatView()
        {
            if (Session["Login"] == null)
            {
                return RedirectToAction("AdminView", "Login");
            }
            int CurrPage;
            int.TryParse(Request.QueryString["page"], out CurrPage);
            CurrPage = CurrPage <= 0 ? 1 : CurrPage;
            Page<deleatinfo> PagesUInfo = Access.GetUserList(CurrPage, 3);
            
            return View(PagesUInfo);
        }
        [HttpPost]
        public ActionResult deleatView(FormCollection uInfo, deleatinfo sk, string action)
        {
            string LoginCode = uInfo["Code"];
            if (action == "冻结")
            {
                Access.AddViewCount3(LoginCode);
                var isadmintips = ("<script>alert('冻结成功！');document.location.href='/deleat/deleatView';</script>");
                return Content(isadmintips);

               
            }
           if(action== "解除冻结")
            {
                Access.AddViewCount4(LoginCode);
                var isadmintips = ("<script>alert('解禁成功！');document.location.href='/deleat/deleatView';</script>");
                return Content(isadmintips);
            }
            if (action == "征收月租费")
            {
                Access.AddViewCount5(LoginCode, 38);
                var isadmintips = ("<script>alert('扣除成功！');document.location.href='/deleat/deleatView';</script>");
                return Content(isadmintips);
            }
            return View();

        }
        #endregion
    }
}