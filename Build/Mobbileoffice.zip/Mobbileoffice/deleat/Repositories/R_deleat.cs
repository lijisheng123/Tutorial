﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PetaPoco;
using deleat.Models;


namespace deleat.Repositories
{
    public class R_deleat
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回查询数据</returns>
        public deleatinfo GetUserDetil(string user)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", user);

            return DB.FirstOrDefault<deleatinfo>(sql);
        }
        /// <summary>
        /// 修改信息
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <returns>返回数据</returns>
        public int AddViewCount2(string ACCOUNT)

        {

            Sql sql2 = Sql.Builder.Append("Update tbl_user set STATUS=2 where mobileNum =@0", ACCOUNT);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
        /// <summary>
        /// 修改信息
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <returns>返回数据</returns>
        public int AddViewCount3(string ACCOUNT)

        {

            Sql sql2 = Sql.Builder.Append("Update tbl_user set STATUS=0 where mobileNum =@0", ACCOUNT);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
        /// <summary>
        /// 修改信息
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <returns>返回数据</returns>
        public int AddViewCount4(string ACCOUNT)

        {

            Sql sql2 = Sql.Builder.Append("Update tbl_user set STATUS=1 where mobileNum =@0", ACCOUNT);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>返回数据</returns>
        public int AddViewCount2(string ACCOUNT, decimal BALANCE)

        {
            string sql = string.Format("Update tbl_user set balance = balance - {0} where mobileNum ={1}", BALANCE, ACCOUNT);
            Sql sql2 = Sql.Builder.Append(sql);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
   
        /// <summary>
        /// 获得数据列表
        /// </summary>
        /// <param name="Page"><页数/param>
        /// <param name="ItemsPerPage"></param>
        /// <returns>返回数据列表</returns>
        public Page<deleatinfo> GetUserList(long Page, long ItemsPerPage)
        {
            Sql sql = Sql.Builder
                .Select("*")
                .From("tbl_user");
              
              
            //查列表 Page 方法
            return DB.Page<deleatinfo>(Page, ItemsPerPage, sql);
        }
      
    }
}
