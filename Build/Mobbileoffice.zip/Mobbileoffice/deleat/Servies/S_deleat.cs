﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using deleat.Models;
using deleat.Repositories;
using PetaPoco;
namespace deleat.Servies
{
  public  class S_deleat
    {
      /// <summary>
      /// 调用Repositories层
      /// </summary>
      /// <param name="ACCOUNT">手机号</param>
      /// <returns>返回数据</returns>
        public int AddViewCount2(string ACCOUNT)

        {
            R_deleat kb = new R_deleat();

            return kb.AddViewCount2(ACCOUNT);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="blance">余额</param>
        /// <returns></returns>
        public int AddViewCount5(string ACCOUNT,decimal blance)

        {
            R_deleat kb = new R_deleat();

            return kb.AddViewCount2(ACCOUNT,blance);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <returns>返回数据</returns>
        public int AddViewCount3(string ACCOUNT)

        {
            R_deleat kb = new R_deleat();

            return kb.AddViewCount3(ACCOUNT);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <returns>返回数据<</returns>
        public int AddViewCount4(string ACCOUNT)

        {
            R_deleat kb = new R_deleat();

            return kb.AddViewCount4(ACCOUNT);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="Page">页数</param>
        /// <param name="ItemsPerPage"></param>
        /// <returns>返回数据</returns>
        public Page<deleatinfo> GetUserList(long Page, long ItemsPerPage)
        {
            R_deleat kb = new R_deleat();

            return kb.GetUserList(Page, ItemsPerPage);
        }
      
    }
}
