﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Mvc;
using Register.Servies;
using Register.Models;

namespace Mobbileoffice.Controllers
{
    public class RegisterController : Controller
    {
        // GET: Register
        /// <summary>
        /// 用户注册
        /// </summary>
        /// <returns>返回数据</returns>
        #region 用户注册
        public ActionResult RegView()
        {
            RegInfo uinfo = new RegInfo();
            return View(uinfo);
        }
        [HttpPost]
        public ActionResult RegView(RegInfo uinfo, FormCollection SK)
        {
            if (!ModelState.IsValid)
            {
                return View(uinfo);
            }
            S_Reg sk = new S_Reg(); 
            string pwd = SK["password"];
            string pwd2 = SK["uPass"];
            if (sk.Login(uinfo.mobileNum))
            {
                if (pwd == pwd2)
                {

                    uinfo.uPass = ReUse.BllUtility.MD5AndSHA1.MD5Encode(uinfo.uPass, "32");
                    uinfo.createdate = DateTime.Now;
                    uinfo.STATUS = 1;
                    uinfo.IsAdmin = 0;
                    uinfo.lasttime = DateTime.Now;
                    uinfo.balance = 0;


                    sk.UserReg(uinfo);
                    return RedirectToAction("LoginView", "Login");

                }
                else
                {
                    ViewBag.sss = "两次密码输入不一致";
                    return View(uinfo);

                }
            }
            else
            {
                ViewBag.kkk = "账号已注册";
                return View(uinfo);
            }
                
            }
           



        }
    #endregion
}
