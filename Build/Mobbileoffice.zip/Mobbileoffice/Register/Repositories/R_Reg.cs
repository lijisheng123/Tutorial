﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Register.Models;
using PetaPoco;
namespace Register.Repositories
{
  public  class R_Reg
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 插入数据
        /// </summary>
        /// <param name="uInfo">手机号</param>
        /// <returns></returns>
        public object UserReg(RegInfo uInfo)
        {
            return DB.Insert("tbl_user", "mobileNum ", uInfo);
        }
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="phone">手机号</param>
        /// <returns></returns>
        public RegInfo GetUserDetil(string phone)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", phone);

            return DB.FirstOrDefault<RegInfo>(sql);
        }

    }
}
