﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Register.Repositories;
using Register.Models;

namespace Register.Servies
{
  public  class S_Reg
    {
        /// <summary>
        ///  调用Repositories
        /// </summary>
        /// <param name="uInfo">手机号</param>
        /// <returns>返回数据</returns>
        public object UserReg(RegInfo uInfo)
        {
            R_Reg sk = new R_Reg();
            return sk.UserReg(uInfo);
        }
        /// <summary>
        ///  调用Repositories
        /// </summary>
        /// <param name="phone">手机号</param>
        /// <returns>返回数据</returns>
        public bool Login(string phone)
        {
            R_Reg us = new R_Reg();
            RegInfo info = us.GetUserDetil(phone);
            if (info==null)
            {
                return true;
            }
            else
            {
                return false;
            }



        }
    }
}
