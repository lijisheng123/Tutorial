﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Register.Models
{
    public class RegInfo
    {
        /// <summary>
        /// 手机号
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "手机号必输输入")]
        [RegularExpression(@"\d{11}", ErrorMessage = "手机号格式不对")]
        public string mobileNum { get; set; }
        /// <summary>
        /// 登录密码
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "密码必输输入")]
        [RegularExpression(@"\d{6}", ErrorMessage = "密码必须由0-9组成的六位数字")]
        public string uPass { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "姓名必输输入")]
        public string uName { get; set; }

        /// <summary>
        /// 性别
        /// </summary>

        public int uSex { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "地址必输输入")]
        public string uAddress { get; set; }
        /// <summary>
        /// 邮编
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = "邮编必输输入")]
        [RegularExpression(@"\d{6}", ErrorMessage = "邮编必须为六位数字")]
        public string uPostcode { get; set; }
        /// <summary>
        /// 电子邮件
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = "电子邮件必输输入")]     
        public string email { get; set; }
        /// <summary>
        ///安全提示问题
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = "安全提示问题必输输入")]
        public string question { get; set; }
        /// <summary>
        /// 安全答案
        /// </summary>   
        [Required(AllowEmptyStrings = false, ErrorMessage = " 安全答案必输输入")]
        public string answer { get; set; }
        /// <summary>
        /// 建造时间
        /// </summary>
        public DateTime createdate { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int STATUS { get; set; }
        /// <summary>
        /// 最后登录时间
        /// </summary>
        public DateTime lasttime { get; set; }
        /// <summary>
        /// 是否为登录员
        /// </summary>
        public int IsAdmin { get; set; }
        /// <summary>
        /// 余额
        /// </summary>
        public decimal balance { get; set; }


    }
}
