﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace inout.Models
{
   public class OutInfo
    {
        /// <summary>
        /// 账号
        /// </summary>

        public string mobileNum { get; set; }
        /// <summary>
        /// 金额
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "金额必输输入")]
        [RegularExpression(@"[0-9]+", ErrorMessage = "格式错误")]
        public Decimal balance { get; set; }

        public string actionName { get; set; }

    }
}
