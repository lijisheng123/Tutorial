﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using inout.Models;
using PetaPoco;
namespace inout.Repositories
{
  public  class R_in
    {
        private Database DB = new Database("ConnString");
        /// <summary>
        /// 插入数据
        /// </summary>
        /// <param name="uInfo">手机号</param>
        /// <returns></returns>
        public object UserReg(inInfo uInfo)
        {
            return DB.Insert("tbl_actlog", "logId ", uInfo);
        }
        /// <summary>
        /// 修改资料
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>返回数据</returns>
        public int AddViewCount(string ACCOUNT, decimal BALANCE)

        {
            string sql = string.Format("Update tbl_user set balance = balance + {0} where mobileNum ={1}", BALANCE, ACCOUNT);
            Sql sql2 = Sql.Builder.Append(sql);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
        /// <summary>
        /// 修改资料
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>返回数据</returns>
        public int AddViewCount2(string ACCOUNT, decimal BALANCE)

        {
            string sql = string.Format("Update tbl_user set balance = balance - {0} where mobileNum ={1}", BALANCE, ACCOUNT);
            Sql sql2 = Sql.Builder.Append(sql);
            return DB.Execute(sql2);//除了select 语句都可以用
        }
        /// <summary>
        /// 查询信息
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回数据</returns>
        public OutInfo GetUserDetil2(string user)
        {
            Sql sql = Sql.Builder.Append("select * from tbl_user where mobileNum=@0", user);

            return DB.FirstOrDefault<OutInfo>(sql);
        }
    }
}
