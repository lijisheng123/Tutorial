﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using inout.Repositories;
using inout.Models;

namespace inout.Servies
{
  public  class S_in
    {
        R_in sb = new R_in();
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="sk">手机号</param>
        /// <returns>返回数据</returns>
        public object UserReg(inInfo sk)
        {


            return sb.UserReg(sk);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>返回数据</returns>

        public int AddViewCount(string ACCOUNT, decimal BALANCE)
        {
            return sb.AddViewCount(ACCOUNT, BALANCE);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="ACCOUNT">手机号</param>
        /// <param name="BALANCE">余额</param>
        /// <returns>返回数据</returns>
        public int AddViewCount2(string ACCOUNT, decimal BALANCE)
        {
            return sb.AddViewCount2(ACCOUNT, BALANCE);
        }
        /// <summary>
        /// 调用Repositories层
        /// </summary>
        /// <param name="user">手机号</param>
        /// <returns>返回数据</returns>
        public OutInfo GetUserDetil2(string user)
        {


            return sb.GetUserDetil2(user);
        }
    }
}
