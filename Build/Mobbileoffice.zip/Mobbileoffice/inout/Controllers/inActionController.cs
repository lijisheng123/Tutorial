﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using inout.Models;
using inout.Servies;
using BankSystem.Controllers.Filters;
using login;


namespace Mobbileoffice.Controllers
{
    [Login]
    public class inActionController : Controller
    {
        login.Models.Logininfo currUseer = UserState.GetUserStatic();
        inInfo sk = new inInfo();
        /// <summary>
        /// 预存话费
        /// </summary>
        /// <returns>返回视图实体类</returns>
        // GET: inAction
        [Login]
        
        #region 预存话费
        public ActionResult inActionView()
        {

            ViewBag.ACCOUNT = currUseer.mobileNum;
            return View(sk);
        }
        /// <summary>
        /// 提交表单
        /// </summary>
        /// <param name="sb">实体类</param>
        /// <returns>返回数据</returns>
        [Login]
        [HttpPost]
        public ActionResult inActionView(inInfo sb)
        {
            //sk.ACCOUNT = Convert.ToInt32(currUseer.ACCOUNT);
            if (!ModelState.IsValid)
            {
                ViewBag.ACCOUNT = currUseer.mobileNum;

                return View(sb);
            }

            ViewBag.ACCOUNT = currUseer.mobileNum;

            sb.mobileNum = currUseer.mobileNum;
            sb.mnType = 1;
            sb.actionName = "预存话费";
            sb.actionTime = DateTime.Now;
            S_in sq = new S_in();

            sq.UserReg(sb);
            sq.AddViewCount(currUseer.mobileNum, sb.mnNum);
            ViewBag.ps1 = "存入成功";
            return View();



        }
        #endregion
        /// <summary>
        /// 通话发短信
        /// </summary>
        /// <returns>返回数据</returns>
        [Login]
        
        #region 通话发短信
        public ActionResult OutActionView()
        {



            OutInfo outin = new OutInfo();
            outin.mobileNum = currUseer.mobileNum;
            S_in sb = new S_in();


            outin = sb.GetUserDetil2(outin.mobileNum);

            ViewBag.ACCOUNT = currUseer.mobileNum;
            ViewBag.BALANCE = outin.balance;
            Session["BALANCE"] = outin.balance;
            OutInfo sd = new OutInfo();
            return View(sd);



        }
        [Login]
        [HttpPost]
        public ActionResult OutActionView(OutInfo sb, FormCollection sw, inInfo info)
        {
          
            string LoginCode = currUseer.mobileNum;
            if (!ModelState.IsValid)
            {
                ViewBag.ACCOUNT = currUseer.mobileNum;
                ViewBag.BALANCE = Session["BALANCE"];
                return View(sb);
            }
            S_in sk = new S_in();
            sb = sk.GetUserDetil2(LoginCode);
         
            decimal money = Convert.ToDecimal(sw["balance"]);


            
                if (sb.balance < money)
                {
                    ViewBag.ACCOUNT = currUseer.mobileNum;
                    ViewBag.BALANCE = sb.balance;
                    ViewBag.ps1 = "您没有那么多钱";
                    return View();
                }
                else
                {
                    ViewBag.ACCOUNT = currUseer.mobileNum;
                    ViewBag.BALANCE = sb.balance;
                    S_in sq = new S_in();
                
                 if (info.actionName == "1")
                {
                    info.actionName = "发短信";
                }
                else
                {
                    info.actionName = "通话";
                }
                info.actionTime = DateTime.Now;
                info.mobileNum = currUseer.mobileNum;
                info.mnNum = money;
                info.mnType = 0;
                sq.UserReg(info);

                    sq.AddViewCount2(LoginCode, money);

                    ViewBag.ps1 = "充值成功";
                    return View(sb);

                }
            }
          

        }
    #endregion
}
